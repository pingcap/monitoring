local grafana = import 'grafonnet-lib/grafonnet/grafana.libsonnet';
local dashboard = grafana.dashboard;
local row = grafana.row;
local graphPanel = grafana.graphPanel;
local prometheus = grafana.prometheus;
local template = grafana.template;

local myNameFlag = 'DS_TEST-CLUSTER';
local myDS = '${' + myNameFlag + '}';

// A new dashboard
local newDash = dashboard.new(
  title='Test-Cluster-TiCI-Meta',
  editable=true,
  graphTooltip='shared_crosshair',
  refresh='30s',
  time_from='now-1h',
)
.addInput(
  name=myNameFlag,
  label='test-cluster',
  type='datasource',
  pluginId='prometheus',
  pluginName='Prometheus',
)
.addTemplate(
  template.new(
    datasource=myDS,
    hide= 2,
    label='K8s-cluster',
    name='k8s_cluster',
    query='label_values(pd_cluster_status, k8s_cluster)',
    refresh='time',
    sort=1,
  )
)
.addTemplate(
  // Default template for tidb-cloud
  template.new(
    allValues=null,
    current=null,
    datasource=myDS,
    hide='all',
    includeAll=false,
    label='tidb_cluster',
    multi=false,
    name='tidb_cluster',
    query='label_values(pd_cluster_status{k8s_cluster="$k8s_cluster"}, tidb_cluster)',
    refresh='time',
    regex='',
    sort=1,
    tagValuesQuery='',
  )
).addTemplate(
  // Default template for tidb-cloud
  template.new(
    allValues='.*',
    current=null,
    datasource=myDS,
    hide='',
    includeAll=true,
    label='Instance',
    multi=false,
    name='instance',
    query='query_result(max by (instance) (up{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", component="tici-meta"} or up{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"tici-meta-.+"}))',
    refresh='time',
    regex='/.*instance="([^"]+)".*/',
    sort=1,
    tagValuesQuery='',
  )
);

// Server row and its panels
local serverRow = row.new(collapse=true, title='Server');
local uptimeP = graphPanel.new(
  title='Uptime',
  datasource=myDS,
  legend_rightSide=true,
  format='s',
  description='Uptime since the last restart.',
)
.addTarget(
  prometheus.target(
    'time() - process_start_time_seconds{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", component="tici-meta"}',
    legendFormat='{{instance}}',
  )
);

local cpuP = graphPanel.new(
  title='CPU Usage',
  datasource=myDS,
  legend_rightSide=true,
  description='',
  format='percentunit',
)
.addTarget(
  prometheus.target(
    'rate(process_cpu_seconds_total{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", component="tici-meta"}[1m])',
    legendFormat='{{instance}}',
  )
);
/*
// TODO: Add cpu quota
.addTarget(
  prometheus.target(
    'tidb_server_maxprocs{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}',
    legendFormat='quota-{{instance}}',
  )
);
*/

local memP = graphPanel.new(
  title='Memory Usage',
  datasource=myDS,
  legend_rightSide=true,
  description='',
  format='bytes',
)
.addTarget(
  prometheus.target(
    'process_resident_memory_bytes{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", component="tici-meta"}',
    legendFormat='{{instance}}',
  )
);
/*
// TODO: Add memory quota
.addTarget(
  prometheus.target(
    'tidb_server_memory_quota_bytes{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}',
    legendFormat='quota-{{instance}}',
  )
);*/

// Summary row and its panels
local shardSummaryRow = row.new(collapse=true, title='Shard Summary');
local shardCount = graphPanel.new(
  title='Shard count',
  datasource=myDS,
  legend_rightSide=true,
  format='none',
  description='',
)
.addTarget(
  prometheus.target(
    'tici_meta_shard_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}',
    legendFormat='{{type}}',
  )
);

local indexCount = graphPanel.new(
  title='Index count',
  datasource=myDS,
  legend_rightSide=true,
  format='none',
  description='',
)
.addTarget(
  prometheus.target(
    'tici_meta_index_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}',
    legendFormat='{{type}}',
  )
);

local shardEvents = graphPanel.new(
  title='Shard Events',
  datasource=myDS,
  legend_rightSide=true,
  format='ops',
)
.addTarget(
  prometheus.target(
    'sum by (type) (rate(tici_meta_shard_event_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m]))',
    legendFormat='{{type}}',
  )
);

local shardTaskDurations = graphPanel.new(
  title='Shard Task Duration',
  datasource=myDS,
  legend_rightSide=true,
  format='s',
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.99, sum(rate(tici_meta_shard_task_duration_bucket{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (le, type))',
    legendFormat='{{type}}-99%',
  )
);

local shardTaskTriggerReason = graphPanel.new(
  title='Shard Task Trigger Reason',
  datasource=myDS,
  legend_rightSide=true,
  format='ops',
)
.addTarget(
  prometheus.target(
    'sum by (reason) (rate(tici_meta_shard_task_trigger_reason_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m]))',
    legendFormat='{{type}}',
  )
);

local backEndDelayDuration = graphPanel.new(
  title='Backend Delay Duration',
  datasource=myDS,
  legend_rightSide=true,
  format='s',
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.99, sum(rate(tici_backend_delay_duration_bucket{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (le, type))',
    legendFormat='{{type}}-99%',
  )
);

local shardTaskQueueDuration = graphPanel.new(
  title='Shard Task Queued Duration',
  datasource=myDS,
  legend_rightSide=true,
  format='s',
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.99, sum(rate(tici_meta_shard_task_queued_bucket{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (le, type))',
    legendFormat='{{type}}-99%',
  )
);

local shardTasksByRunner = graphPanel.new(
  title='Shard Tasks By Runner',
  datasource=myDS,
  legend_rightSide=true,
  format='ops',
)
.addTarget(
  prometheus.target(
    'sum by (type) (rate(tici_meta_shard_task_by_runner_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m]))',
    legendFormat='{{id}}-{{type}}',
  )
);

// GRPC Row
local grpcRow = row.new(collapse=true, title='GRPC');
local grpcRequestDuration = graphPanel.new(
  title='Grpc Request Duration',
  datasource=myDS,
  legend_rightSide=true,
  format='s',
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.99, sum(rate(tici_grpc_handle_duration_bucket{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (le, type))',
    legendFormat='{{type}}-99%',
  )
);

// Shard Cache row and its panels
local shardCacheRow = row.new(collapse=true, title='Shard Cache');

local readerCount = graphPanel.new(
  title='Active Readers',
  datasource=myDS,
  legend_rightSide=true,
  format='none',
  description='Active reader nodes in pool',
)
.addTarget(
  prometheus.target(
    'tici_meta_shard_cache_reader_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}',
    legendFormat='active-readers',
  )
);

local cacheHitMiss = graphPanel.new(
  title='Cache Hit/Miss Rate',
  datasource=myDS,
  legend_rightSide=true,
  format='ops',
)
.addTarget(
  prometheus.target(
    'rate(tici_meta_shard_cache_query_duration_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", type=~"hit"}[5m])',
    legendFormat='hit-{{instance}}',
  )
)
.addTarget(
  prometheus.target(
    'rate(tici_meta_shard_cache_query_duration_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", type=~"miss"}[5m])',
    legendFormat='miss-{{instance}}',
  )
);

local cacheHitRatio = graphPanel.new(
  title='Cache Hit Ratio',
  datasource=myDS,
  legend_rightSide=true,
  format='percentunit',
)
.addTarget(
  prometheus.target(
    'sum(rate(tici_meta_shard_cache_query_duration_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", type=~"hit"}[5m]))
     /
     sum(rate(tici_meta_shard_cache_query_duration_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[5m]))',
    legendFormat='hit-ratio',
  )
);

local warmupReqP95 = graphPanel.new(
  title='Warmup req P95',
  datasource=myDS,
  legend_rightSide=true,
  format='s',
  description='Shard cache warmup latency p95',
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.95, sum by (le) (rate(tici_meta_shard_cache_warm_up_req_latency_bucket{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[5m])))',
    legendFormat='p95',
  )
);

local warmupQueueP95 = graphPanel.new(
  title='Warmup queue P95',
  datasource=myDS,
  legend_rightSide=true,
  format='s',
  description='Shard cache warmup queue latency p95',
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.95, sum by (le) (rate(tici_meta_shard_cache_warm_up_queued_bucket{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[5m])))',
    legendFormat='p95',
  )
);

local shardCacheCount = graphPanel.new(
  title='Shard Cache Count',
  datasource=myDS,
  legend_rightSide=true,
  format='none',
  description='Current number of shard cache allocations',
)
.addTarget(
  prometheus.target(
    'tici_meta_shard_cache_count_gauge{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}',
    legendFormat='{{type}}',
  )
);

local queryDurationP95 = graphPanel.new(
  title='Query duration P95',
  datasource=myDS,
  legend_rightSide=true,
  format='s',
  description='Shard cache warmup queue latency p95',
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.95, sum by (le) (rate(tici_meta_shard_cache_query_duration_bucket{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", type=~"hit"}[5m])))',
    legendFormat='hit-p95',
  )
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.95, sum by (le) (rate(tici_meta_shard_cache_query_duration_bucket{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", type=~"need_warm"}[5m])))',
    legendFormat='need_warm-p95',
  )
);

local shardCacheEvent = graphPanel.new(
  title='Shard Cache Event',
  datasource=myDS,
  legend_rightSide=true,
  format='ops',
)
.addTarget(
  prometheus.target(
    'rate(tici_meta_shard_cache_event_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[5m])',
    legendFormat='{{type}}',
  )
);

// S3 row and its panels
local s3Row = row.new(collapse=true, title='S3');

local s3RequestDuration = graphPanel.new(
  title='S3 Request Duration',
  datasource=myDS,
  legend_rightSide=true,
  format='none',
  description='S3 request duration',
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.99, sum(rate(tici_s3_request_duration{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (le, type))',
    legendFormat='{{type}}-99%',
  )
);

// Merge together.
local panelW = 12;
local panelH = 7;
local rowW = 24;
local rowH = 1;

local rowPos = {x:0, y:0, w:rowW, h:rowH};
local leftPanelPos = {x:0, y:0, w:panelW, h:panelH};
local rightPanelPos = {x:panelW, y:0, w:panelW, h:panelH};

newDash
.addPanel(
  serverRow
  .addPanel(uptimeP, gridPos=leftPanelPos)
  .addPanel(cpuP, gridPos=rightPanelPos)
  .addPanel(memP, gridPos=leftPanelPos)
  ,
  gridPos=rowPos
)
.addPanel(
  shardSummaryRow
  .addPanel(shardCount, gridPos=leftPanelPos)
  .addPanel(indexCount, gridPos=rightPanelPos)
  .addPanel(shardEvents, gridPos=leftPanelPos)
  .addPanel(shardTaskTriggerReason, gridPos=rightPanelPos)
  .addPanel(shardTaskDurations, gridPos=leftPanelPos)
  .addPanel(shardTaskQueueDuration, gridPos=rightPanelPos)
  .addPanel(backEndDelayDuration, gridPos=leftPanelPos)
  .addPanel(shardTasksByRunner, gridPos=rightPanelPos)
  ,
  gridPos=rowPos
)
.addPanel(
  shardCacheRow
  .addPanel(readerCount, gridPos=leftPanelPos)
  .addPanel(shardCacheCount, gridPos=rightPanelPos)
  .addPanel(cacheHitRatio, gridPos=leftPanelPos)
  .addPanel(cacheHitMiss, gridPos=rightPanelPos)
  .addPanel(warmupQueueP95, gridPos=leftPanelPos)
  .addPanel(warmupReqP95, gridPos=rightPanelPos)
  .addPanel(queryDurationP95, gridPos=leftPanelPos)
  .addPanel(shardCacheEvent, gridPos=rightPanelPos)
  ,
  gridPos=rowPos
)
.addPanel(
  grpcRow
  .addPanel(grpcRequestDuration, gridPos=leftPanelPos)
  ,
  gridPos=rowPos
)
.addPanel(
  s3Row
  .addPanel(s3RequestDuration, gridPos=leftPanelPos)
  ,
  gridPos=rowPos
)
