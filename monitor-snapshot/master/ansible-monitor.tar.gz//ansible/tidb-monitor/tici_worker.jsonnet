local grafana = import 'grafonnet-lib/grafonnet/grafana.libsonnet';
local dashboard = grafana.dashboard;
local row = grafana.row;
local graphPanel = grafana.graphPanel;
local prometheus = grafana.prometheus;
local template = grafana.template;

local myNameFlag = 'DS_TEST-CLUSTER';
local myDS = '${' + myNameFlag + '}';

// A new dashboard
local newDash = dashboard.new(
  title='Test-Cluster-TiCI-Worker',
  editable=true,
  graphTooltip='shared_crosshair',
  refresh='30s',
  time_from='now-1h',
)
.addInput(
  name=myNameFlag,
  label='test-cluster',
  type='datasource',
  pluginId='prometheus',
  pluginName='Prometheus',
)
.addTemplate(
  template.new(
    datasource=myDS,
    hide= 2,
    label='K8s-cluster',
    name='k8s_cluster',
    query='label_values(pd_cluster_status, k8s_cluster)',
    refresh='time',
    sort=1,
  )
)
.addTemplate(
  // Default template for tidb-cloud
  template.new(
    allValues=null,
    current=null,
    datasource=myDS,
    hide='all',
    includeAll=false,
    label='tidb_cluster',
    multi=false,
    name='tidb_cluster',
    query='label_values(pd_cluster_status{k8s_cluster="$k8s_cluster"}, tidb_cluster)',
    refresh='time',
    regex='',
    sort=1,
    tagValuesQuery='',
  )
).addTemplate(
  // Default template for tidb-cloud
  template.new(
    allValues='.*',
    current=null,
    datasource=myDS,
    hide='',
    includeAll=true,
    label='Instance',
    multi=false,
    name='instance',
    query='query_result(max by (instance) (up{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", component="tici-worker"} or up{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"tici-worker-.+"}))',
    refresh='time',
    regex='/.*instance="([^"]+)".*/',
    sort=1,
    tagValuesQuery='',
  )
);

// Server row and its panels
local serverRow = row.new(collapse=true, title='Server');
local uptimeP = graphPanel.new(
  title='Uptime',
  datasource=myDS,
  legend_rightSide=true,
  format='s',
  description='Uptime since the last restart.',
)
.addTarget(
  prometheus.target(
    'time() - process_start_time_seconds{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", component="tici-worker"}',
    legendFormat='{{instance}}',
  )
);

local cpuP = graphPanel.new(
  title='CPU Usage',
  datasource=myDS,
  legend_rightSide=true,
  description='',
  format='percentunit',
)
.addTarget(
  prometheus.target(
    'rate(process_cpu_seconds_total{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", component="tici-worker"}[1m])',
    legendFormat='{{instance}}',
  )
);
/*
// TODO: Add cpu quota
.addTarget(
  prometheus.target(
    'tidb_server_maxprocs{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}',
    legendFormat='quota-{{instance}}',
  )
);
*/

local memP = graphPanel.new(
  title='Memory Usage',
  datasource=myDS,
  legend_rightSide=true,
  description='',
  format='bytes',
)
.addTarget(
  prometheus.target(
    'process_resident_memory_bytes{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", component="tici-worker"}',
    legendFormat='{{instance}}',
  )
);
/*
// TODO: Add memory quota
.addTarget(
  prometheus.target(
    'tidb_server_memory_quota_bytes{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}',
    legendFormat='quota-{{instance}}',
  )
);*/

// CDC row
local cdcRow = row.new(collapse=true, title='CDC');
local cdcEventOPSPanel = graphPanel.new(
  title='CDC Event OPS',
  datasource=myDS,
  legend_rightSide=true,
  format='ops',
  description='CDC event ops.',
)
.addTarget(
  prometheus.target(
    'sum by (type) (rate(tici_writer_cdc_event_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m]))',
    legendFormat='{{type}}',
  )
)
.addTarget(
  prometheus.target(
    'sum(rate(tici_writer_cdc_event_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m]))',
    legendFormat='Total',
  )
);

local cdcEventTotalPanel = graphPanel.new(
  title='CDC Event Total Count',
  datasource=myDS,
  legend_rightSide=true,
  format='none',
  description='Total CDC event count accumulated over time.',
)
.addTarget(
  prometheus.target(
    'sum by (type) (tici_writer_cdc_event_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"})',
    legendFormat='{{type}}',
  )
)
.addTarget(
  prometheus.target(
    'sum(tici_writer_cdc_event_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"})',
    legendFormat='Total',
  )
);

local cdcOperationPanel = graphPanel.new(
  title='CDC Operations',
  datasource=myDS,
  legend_rightSide=true,
  format='ops',
)
.addTarget(
  prometheus.target(
    'sum by (type) (rate(tici_writer_cdc_operation_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m]))',
    legendFormat='{{type}}',
  )
);

local cdcOperationLatencyPanel = graphPanel.new(
  title='CDC Operation Latency',
  datasource=myDS,
  legend_rightSide=true,
  format='s',
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.99, sum(rate(tici_writer_cdc_operation_latency_bucket{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (le, type))',
    legendFormat='{{type}}-99',
  )
)
.addTarget(
  prometheus.target(
    'sum(rate(tici_writer_cdc_operation_latency_sum{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (type) / sum(rate(tici_writer_cdc_operation_latency_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (type)',
    legendFormat='{{type}}-avg',
  )
);

// Fragment row
local fragRow = row.new(collapse=true, title='Frag');

local fragOperationPanel = graphPanel.new(
  title='Fragment Operations',
  datasource=myDS,
  legend_rightSide=true,
  format='ops',
)
.addTarget(
  prometheus.target(
    'sum by (type) (rate(tici_writer_frag_operation_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m]))',
    legendFormat='{{type}}',
  )
);

local fragOperationLatencyPanel = graphPanel.new(
  title='Fragment Operation Latency',
  datasource=myDS,
  legend_rightSide=true,
  format='ms',
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.99, sum(rate(tici_writer_frag_operation_latency_bucket{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (le, type))',
    legendFormat='{{type}}-99',
  )
)
.addTarget(
  prometheus.target(
    'sum(rate(tici_writer_frag_operation_latency_sum{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (type) / sum(rate(tici_writer_frag_operation_latency_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (type)',
    legendFormat='{{type}}-avg',
  )
);

// GRPC Row
local grpcRow = row.new(collapse=true, title='GRPC');
local grpcRequestDuration = graphPanel.new(
  title='Grpc Request Duration',
  datasource=myDS,
  legend_rightSide=true,
  format='s',
)
  .addTarget(
  prometheus.target(
    'histogram_quantile(0.99, sum(rate(tici_grpc_handle_duration_bucket{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", service="worker"}[1m])) by (le, type))',
    legendFormat='{{type}}-99%',
  )
);

local grpcRequestOPS = graphPanel.new(
  title='Grpc Request OPS',
  datasource=myDS,
  legend_rightSide=true,
  format='ops',
)
.addTarget(
  prometheus.target(
    'sum by (type, result) (rate(tici_grpc_handle_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", service="worker"}[1m]))',
    legendFormat='{{type}}-{{result}}',
  )
);

local grpcRequestInflight = graphPanel.new(
  title='Grpc Request Inflight',
  datasource=myDS,
  legend_rightSide=true,
  format='none',
)
.addTarget(
  prometheus.target(
    'sum by (service, type) (tici_grpc_handle_inflight{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance", service="worker"})',
    legendFormat='{{service}}-{{type}}',
  )
);

// Meta client row and its panels
local metaClientRow = row.new(collapse=true, title='Meta Client');

local metaClientGrpcDuration = graphPanel.new(
  title='Meta Client Grpc Duration',
  datasource=myDS,
  legend_rightSide=true,
  format='s',
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.99, sum(rate(tici_meta_client_grpc_handle_duration_bucket{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (le, type))',
    legendFormat='{{type}}-99',
  )
)
.addTarget(
  prometheus.target(
    'sum(rate(tici_meta_client_grpc_handle_duration_sum{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (type) / sum(rate(tici_meta_client_grpc_handle_duration_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (type)',
    legendFormat='{{type}}-avg',
  )
);

local metaClientGrpcOPS = graphPanel.new(
  title='Meta Client Grpc OPS',
  datasource=myDS,
  legend_rightSide=true,
  format='ops',
)
.addTarget(
  prometheus.target(
    'sum by (type, result) (rate(tici_meta_client_grpc_handle_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m]))',
    legendFormat='{{type}}-{{result}}',
  )
);

local metaClientGrpcInflight = graphPanel.new(
  title='Meta Client Grpc Inflight',
  datasource=myDS,
  legend_rightSide=true,
  format='none',
)
.addTarget(
  prometheus.target(
    'sum by (type) (tici_meta_client_grpc_handle_inflight{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"})',
    legendFormat='{{type}}',
  )
);

// Dedup row and its panels
local dedupRow = row.new(collapse=true, title='Dedup');

local dedupRunOPS = graphPanel.new(
  title='Dedup Run OPS',
  datasource=myDS,
  legend_rightSide=true,
  format='ops',
)
.addTarget(
  prometheus.target(
    'sum by (result) (rate(tici_dedup_run_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m]))',
    legendFormat='{{result}}',
  )
);

local dedupInProgress = graphPanel.new(
  title='Dedup In Progress',
  datasource=myDS,
  legend_rightSide=true,
  format='none',
)
.addTarget(
  prometheus.target(
    'tici_dedup_in_progress{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}',
    legendFormat='{{instance}}',
  )
);

local dedupStageLatency = graphPanel.new(
  title='Dedup Stage Latency',
  datasource=myDS,
  legend_rightSide=true,
  format='s',
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.99, sum(rate(tici_dedup_stage_latency_bucket{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (le, stage))',
    legendFormat='{{stage}}-99',
  )
)
.addTarget(
  prometheus.target(
    'sum(rate(tici_dedup_stage_latency_sum{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (stage) / sum(rate(tici_dedup_stage_latency_count{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (stage)',
    legendFormat='{{stage}}-avg',
  )
);

// S3 row and its panels
local s3Row = row.new(collapse=true, title='S3');

local s3RequestDuration = graphPanel.new(
  title='S3 Request Duration',
  datasource=myDS,
  legend_rightSide=true,
  format='none',
  description='S3 request duration',
)
.addTarget(
  prometheus.target(
    'histogram_quantile(0.99, sum(rate(tici_s3_request_duration{k8s_cluster="$k8s_cluster", tidb_cluster="$tidb_cluster", instance=~"$instance"}[1m])) by (le, type))',
    legendFormat='{{type}}-99%',
  )
);

// Merge together.
local panelW = 12;
local panelH = 7;
local rowW = 24;
local rowH = 1;

local rowPos = {x:0, y:0, w:rowW, h:rowH};
local leftPanelPos = {x:0, y:0, w:panelW, h:panelH};
local rightPanelPos = {x:panelW, y:0, w:panelW, h:panelH};

newDash
.addPanel(
  serverRow
  .addPanel(uptimeP, gridPos=leftPanelPos)
  .addPanel(cpuP, gridPos=rightPanelPos)
  .addPanel(memP, gridPos=leftPanelPos)
  ,
  gridPos=rowPos
)
.addPanel(
  cdcRow
  .addPanel(cdcEventOPSPanel, gridPos=leftPanelPos)
  .addPanel(cdcEventTotalPanel, gridPos=rightPanelPos)
  .addPanel(cdcOperationPanel, gridPos=leftPanelPos)
  .addPanel(cdcOperationLatencyPanel, gridPos=rightPanelPos)
  ,
  gridPos=rowPos
)
.addPanel(
  fragRow
  .addPanel(fragOperationPanel, gridPos=leftPanelPos)
  .addPanel(fragOperationLatencyPanel, gridPos=rightPanelPos)
  ,
  gridPos=rowPos
)
.addPanel(
  grpcRow
  .addPanel(grpcRequestDuration, gridPos=leftPanelPos)
  .addPanel(grpcRequestOPS, gridPos=rightPanelPos)
  .addPanel(grpcRequestInflight, gridPos=leftPanelPos)
  ,
  gridPos=rowPos
)
.addPanel(
  metaClientRow
  .addPanel(metaClientGrpcDuration, gridPos=leftPanelPos)
  .addPanel(metaClientGrpcOPS, gridPos=rightPanelPos)
  .addPanel(metaClientGrpcInflight, gridPos=leftPanelPos)
  ,
  gridPos=rowPos
)
.addPanel(
  dedupRow
  .addPanel(dedupRunOPS, gridPos=leftPanelPos)
  .addPanel(dedupInProgress, gridPos=rightPanelPos)
  .addPanel(dedupStageLatency, gridPos=leftPanelPos)
  ,
  gridPos=rowPos
)
.addPanel(
  s3Row
  .addPanel(s3RequestDuration, gridPos=leftPanelPos)
  ,
  gridPos=rowPos
)
