## Usage

1. Modify the jsonnet files (e.g. tici_meta.jsonnet).
2. Run `generate_json.sh` to generate the json files by the jsonnet files.
3. Commit the modifications.
