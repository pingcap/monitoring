#!/usr/bin/env bash
set -euo pipefail

go install github.com/google/go-jsonnet/cmd/jsonnet@latest

GRAFONNET_DIR="grafonnet-lib"
if [ ! -d "$GRAFONNET_DIR" ]; then
  echo "Cloning grafonnet-lib..."
  # ref https://github.com/grafana/grafonnet-lib/issues/338, use the forked
  # repo which implements the addOverride and addTransformation funtion for
  # new table.
  # TODO: update to https://github.com/grafana/grafonnet
  git clone https://github.com/nolouch/grafonnet-lib.git "$GRAFONNET_DIR"
fi

export JSONNET_PATH="$GRAFONNET_DIR"

jsonnet tici_meta.jsonnet > tici_meta.json
jsonnet tici_worker.jsonnet > tici_worker.json
jsonnet tici_reader.jsonnet > tici_reader.json
